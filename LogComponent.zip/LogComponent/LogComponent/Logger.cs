﻿/// <summary>
/// Class for writing log information
/// </summary>
///<remarks>
///Created By Jithesh K
///30/04/2016
/// </remarks>
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Configuration;
namespace LogComponent
{
    public class Logger:ILog
    {
        
        private static Logger lInstance = null;
        private static readonly object objLock = new object();
        private static readonly object objWriteLock = new object();
        private int cancellationStatus = 0;
        Queue<string> LogMessages = new Queue<string>();
        System.Timers.Timer timerLog;
        double logInterval=0;

        private Logger()
        {                      
            //Default Value
            logInterval = 100;
            timerLog = new System.Timers.Timer(logInterval);
            timerLog.Elapsed += TimerLog_Elapsed;
            timerLog.Start();
        }
        //Timer event for dequeueing log messages and call write method
        private  void TimerLog_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (cancellationStatus != 2)
            {
                if (LogMessages.Count > 0)
                {

                    string message = LogMessages.Dequeue();
                    WriteLog(message);

                }
            }
            else
            {
                if(LogMessages.Count > 0)
                {
                    LogMessages.Clear();
                }
                
            }
        }
        //Method for getting class instance
        public static Logger GetLoggerInstance()
        {
                      
                if(lInstance == null)
                {
                    lock (objLock)
                    {
                        lInstance = new Logger();
                    }
                }
               return lInstance;
           
                
        }
        //Adding messages to queue
        public void Log(string logMEssage)
        {
            try

            {

                if (cancellationStatus == 0)
                {
                    LogMessages.Enqueue(logMEssage);
                }

               
            }

            catch (Exception ex)
            {

            }
        }
        //Get file name for the log file
        private string GetFile(DateTime currDate)
        {
            String fileName = currDate.ToString("yyyyMMdd")+".txt";
            return fileName;
        }
        //Writing messages from queue to the log file
        private void WriteLog(string lgMessage)
        {
            lock (objWriteLock)
            {
                
                string fileName = GetFile(DateTime.Now);
                lgMessage = lgMessage + Environment.NewLine;
                byte[] encodedText = Encoding.Unicode.GetBytes(lgMessage);
                using (FileStream sourceStream = new FileStream(fileName,
                       FileMode.Append, FileAccess.Write, FileShare.None,
                       bufferSize: 4096, useAsync: false))
                {

                    sourceStream.Write(encodedText, 0, encodedText.Length);
                    sourceStream.Close();
                    
                }
              

            }
           
        }

        //Method for cancelling log writing.
        //Option=1 stop enqueueing and write pending items in the queue
        //Option=2 stop enqueueing and ignore pending items in the queue 
        public void StopWriting(int stopOption)
        {
            cancellationStatus = stopOption;
        }

      
    }
}
