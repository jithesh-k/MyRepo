﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogComponent
{
     public interface ILog
    {
        void Log(string logMEssage);
        void StopWriting(int stopOption);
    }

    
}
