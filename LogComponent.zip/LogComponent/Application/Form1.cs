﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LogComponent;
namespace Application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int iNumber = Convert.ToInt32(txtNumber.Text);
            int iResult = 0;
            
            for(int i=0;i<iNumber;i++)
            {
                iResult += i;

                txtSum.Text = Convert.ToString(iResult);
            }
        }
    }
}
