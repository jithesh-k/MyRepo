﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LogComponent;

namespace ClientApplication
{
    public partial class Home : Form
    {
        int cancelOptions = 0;
        public Home()
        {
            InitializeComponent();
        }
        
        ILog iLogger = Logger.GetLoggerInstance();
        
        private  void btnStart_Click(object sender, EventArgs e)
        {
            //Reset Log Cancel Setting
            iLogger.StopWriting(0);
            long iNumber = Convert.ToInt64(txtNumber.Text);
            long iResult = 0;

            if (rdbAscending.Checked)
            {

                for (int i = 0; i < iNumber; i++)
                {
                    iResult = i;
                    iLogger.Log("Current Value is :" + iResult.ToString());
                    txtResult.Text = iResult.ToString();
                }
            }
            else
            {
                for (long i = iNumber; i > 0; i--)
                {
                    iResult = i;
                    iLogger.Log("Current Value is :" + iResult.ToString());
                    txtResult.Text = iResult.ToString();
                }
            }
            
        }

        private  void btnCancel_Click(object sender, EventArgs e)
        {
            cancelOptions = 2;
            iLogger.StopWriting(cancelOptions);
        }

        
        private void btnFinishCancel_Click(object sender, EventArgs e)
        {
            cancelOptions = 1;
            iLogger.StopWriting(cancelOptions);
        }
    }
}
