﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using LogComponent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogComponentTest
{
    [TestClass()]
    public class LoggerTests
    {
        
        [TestMethod()]
        public void LogTest()
        {
            ILog iLogger = Logger.GetLoggerInstance();
            //Clear existing file
            DateTime currDate = DateTime.Now;
            string currFile = currDate.ToString("yyyyMMdd") + ".txt";
            if(System.IO.File.Exists(currFile))
            {
                System.IO.File.Delete(currFile);

            }
            //Write Dummy Data to Log
            iLogger.Log("Message writter for testing");
            System.Threading.Thread.Sleep(500);
            //Check if file is created
            DateTime currDateN = DateTime.Now;
            string currFileN = currDate.ToString("yyyyMMdd") + ".txt";
            bool logResult = false;
            if (System.IO.File.Exists(currFileN))

            {
                System.IO.FileInfo fileInfo = new System.IO.FileInfo(currFileN);
                if(fileInfo.Length > 0)
                {
                    logResult = true;
                }

            }
            Assert.IsTrue(logResult);
        }

        [TestMethod()]
        public void StopWritingTestPartial()
        {
            ILog iLogger = Logger.GetLoggerInstance();
            PrivateObject pObject = new PrivateObject(iLogger);
            //reset log cancellation status
            iLogger.StopWriting(0);
            //Clear existing file
            DateTime currDate = DateTime.Now;
            string currFile = currDate.ToString("yyyyMMdd") + ".txt";
            if (System.IO.File.Exists(currFile))
            {
                System.IO.File.Delete(currFile);

            }
            //Get Dummy Log Values From Repository
            IList<string> repoList = LogRepository.GetLogRepository(1000);
            int icurrent = 0;
            foreach(string listItem in repoList)
            {
                iLogger.Log(listItem);
                icurrent += 1;
                if(icurrent==100)
                {
                   // Complete Cancel param = 2,partial Cancel param = 1
                   //partial cancel.Should write items in queue and stop enqueing
                    iLogger.StopWriting(1);
                }
            }
            DateTime currDateN = DateTime.Now;
            string currFileN = currDate.ToString("yyyyMMdd") + ".txt";
            
                        
            int logFileLineCount = 0;
            System.Threading.Thread.Sleep(100000);
            if (System.IO.File.Exists(currFileN))
            {
                //Read contents of file
                IEnumerable<string> fileLines = System.IO.File.ReadLines(currFileN,Encoding.UTF8);
                logFileLineCount = fileLines.Count();  
            }
            Queue<String> logQueue =(Queue<string>) pObject.GetField("LogMessages");
            Assert.AreNotEqual(repoList.Count, logQueue.Count);
            Assert.AreEqual(0,logQueue.Count);
            
        }

        [TestMethod()]
        public void StopWritingTestFull()
        {
            ILog iLogger = Logger.GetLoggerInstance();
            PrivateObject pObject = new PrivateObject(iLogger);
            //reset log cancellation status
            iLogger.StopWriting(0);
            //Clear existing file
            DateTime currDate = DateTime.Now;
            string currFile = currDate.ToString("yyyyMMdd") + ".txt";
            if (System.IO.File.Exists(currFile))
            {
                System.IO.File.Delete(currFile);

            }
            //Get Dummy Log Values From Repository
            IList<string> repoList = LogRepository.GetLogRepository(1000);
            int iCurrent = 0;
            foreach (string listItem in repoList)
            {
                iLogger.Log(listItem);

                iCurrent += 1;

                if (iCurrent == 500)
                {
                    System.Threading.Thread.Sleep(1000);
                    // Complete Cancel param = 2,partial Cancel param = 1
                    //partial cancel.Should write items in queue and stop enqueing
                    iLogger.StopWriting(2);
                }
            }
            DateTime currDateN = DateTime.Now;
            string currFileN = currDate.ToString("yyyyMMdd") + ".txt";

            System.Threading.Thread.Sleep(100000);
            int logFileLineCount = 0;
            if (System.IO.File.Exists(currFileN))
            {
                //Read contents of file
                String[] fileLines = System.IO.File.ReadAllLines(currFileN);
                logFileLineCount = fileLines.Count();
                
            }
            //Assert.AreNotEqual(repoList.Count, 500);
            //Assert.AreNotEqual(500, logFileLineCount);
            Queue<String> logQueue = (Queue<string>)pObject.GetField("LogMessages");

            Assert.AreNotEqual(repoList.Count, logQueue.Count);
            Assert.AreNotEqual(0, logFileLineCount);

        }

        [TestMethod]
        public void CheckFileName()
        {
            ILog iLogger = Logger.GetLoggerInstance();
            PrivateObject pObject = new PrivateObject(iLogger);
            DateTime currDate = DateTime.Now;
            var retValue = pObject.Invoke("GetFile", currDate);
            var expectedValue = currDate.ToString("yyyyMMdd") + ".txt";
            Assert.AreEqual(expectedValue, retValue);
            DateTime nextDate = DateTime.Now.AddDays(1);
            var retValueNext = pObject.Invoke("GetFile", nextDate);
            var expectedValueNext = nextDate.ToString("yyyyMMdd") + ".txt";
            Assert.AreEqual(expectedValueNext, retValueNext);
            //pObject.Invoke()
        }
    }
}