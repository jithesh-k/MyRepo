﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogComponentTest
{
    public static class LogRepository
    {
        public static IList<string> GetLogRepository(int repoSize)
        {
            IList<string> logRepoList = new List<string>();
            for(int i=0;i<repoSize;i++ )
            {
                logRepoList.Add("This is item at position " + i.ToString());
            }
            return logRepoList;
        } 
    }
}
